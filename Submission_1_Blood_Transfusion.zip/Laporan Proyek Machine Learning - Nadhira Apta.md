
# Laporan Proyek Machine Learning - Nadhira Apta Maheswari

  

## Domain Proyek
 
Angka kematian akibat kekurangan stok darah relatif tinggi di negara berkembang. Hal ini disebabkan oleh ketidakseimbangan antara kebutuhan darah rumah sakit dan jumlah darah yang dikonsumsi.Tingkat penyumbang Indonesia adalah 6–10 orang per 1.000 orang, jauh lebih rendah dibandingkan dengan beberapa negara maju di Asia.

World Health Organization (WHO) menyatakan bahwa kekurangan darah telah menyebabkan kematian dan gangguan kesehatan bagi banyak pasien. Sekitar 108 juta unit darah disumbangkan setiap tahun di seluruh dunia. Lebih dari 20% dari populasi global, atau hampir 50% dari donor darah, berasal dari negara-negara berpenghasilan tinggi.

Berdasarakan latar belakang ini, maka tujuan dari proyek ini adalah untuk memprediksi apakah seseorang akan mendonasikan darah berdasarkan dari sejarah donasi darah mereka. Hal ini penting untuk meningkatkan jumlah donor darah di negara berkembang, yang pada akhirnya dapat mengurangi angka kematian karena kekurangan stok darah.

Rumah sakit dan lembaga transfusi darah dapat menggunakan model prediksi ini untuk mengelola sumber daya dan menargetkan donor darah dengan lebih efisien. Ini akan meningkatkan efisiensi penargetan donor darah dan manajemen stok darah saat ini, sehingga lebih mudah memenuhi kebutuhan darah rumah sakit.

Referensi: [Pengaruh Kualitas Pelayanan Terhadap Kepuasan Dan Kepercayaan Konsumen Di UPT Transfusi Darah Dinas Kesehatan Provinsi Sulawesi Selatan](http://pasca-umi.ac.id/index.php/jmch/article/view/253)

  

## Business Understanding


### Problem Statements
Angka kematian akibat kekurangan darah masih tinggi di negara berkembang, hal ini disebabkan oleh ketidakseimbangan antara jumlah darah yang tersedia dan kebutuhan rumah sakit. Di Indonesia, tingkat penyumbang darah terhitung sangat rendah, hanya antara 6 dan 10 orang per 1.000 orang, dan kekurangan darah ini dapat menyebabkan kematian dan masalah kesehatan bagi banyak pasien.  
  
Untuk mengatasi masalah ini, harus ditemukan cara yang efektif untuk meningkatkan partisipasi donor darah. Salah satu cara yang dapat dilakukan adalah dengan memprediksi apakah seorang donor darah akan kembali menyumbangkan darah di masa mendatang. Dengan cara ini, kita dapat menargetkan donor yang berpotensi untuk kembali menyumbangkan darah, sehingga stok darah dapat dikelola dengan lebih baik dan efisien.

### Goals

Berikut adalah tujuan dari proyek ini:

- Membuat model prediksi yang akurat untuk menentukan apakah seseorang akan mendonasikan darah lagi berdasarkan sejarah donasi mereka.
- Mengidentifikasi pola donasi untuk membantu meningkatkan partisipasi donor darah di masa mendatang.


### Solution statements

Berikut adalah solusi dilakukan oleh penulis:
- Membuat dua model untuk melakukan prediksi, yaitu support vector machine (SVM) dan k-nearest neighbors algorithm (KNN)
- Melakukan hyperparameter untuk meningkatkan performa model SVM dan KNN

  

## Data Understanding

Data  diambil dari Blood Transfusion Service Center di Hsin-Chu City, Taiwan. Data ini berbasis data donor dari pusat layanan transfusi darah tersebut. Ada 748 data donor yang dipilih secara acak dari basis data donor tersebut. Data ini telah dibagi menjadi data latih dan data uji, dengan 598 data digunakan sebagai train dataset dan 150 data lainnya sebagai test dataset. 

Dataset yang dipakai: [Blood Transfusion Dataset](https://www.kaggle.com/datasets/whenamancodes/blood-transfusion-dataset?phase=FinishSSORegistration&returnUrl=/datasets/whenamancodes/blood-transfusion-dataset/versions/2?resource=download&SSORegistrationToken=CfDJ8OV3w-Vr_2dIpZxXY9wVZZmI3ZLI9cWxJ_SxGNTbKE3YXrqJj-KqkzPlvFm4d85gOKJhYAFCPWyI4N1EptJjZY5JRMrTmO0Myq8Kr7AWmXPufFHmzVqNQtPE6H_GHXHpHxMPc5VXrK0XKps8W8t0qdvyiilJU_Q9aah3h0Cwh2-kbXxtNq5NuHwdP2rtJoT-n1V7sXSjMjm7k_5rx5DHwphuTuD11nlGlN7ZH5_2hM5MpT2B-0Pur8Cj_0xki_s9WGitnVvxExvz7LYuRtxMzDk3oaGsJYDfETRMYhCXXM96twNK5FGinKrrR0w_bZdsKLg2ZhgmTLJVuv2dsiDIvK6GDdY&DisplayName=Nadhira%20Apta).

  

Selanjutnya uraikanlah seluruh variabel atau fitur pada data. Sebagai contoh:

  

### Variabel-variabel pada Blood Transfusion Dataset adalah sebagai berikut:

- R (Recency): bulan sejak donor darah terakhir
- F (Frequency): jumlah total donor darah
- M (Monetary): total darah yang didonorkan dalam c.c.
- T (Time): bulan sejak donasi pertama
- whether he/she donated blood in March 2007: variabel biner yang mewakili apakah dia mendonorkan darah pada bulan Maret 2007 (1 berarti mendonor darah; 0 berarti tidak mendonor darah)

Untuk memahami data, penulis melihat tipe data dengan melihat tabel informasi serta dengan melihat informasi mengenai total, rata-rata, angka minimal, dan angka maximal

**Missing value dan outlier**
Pengecekan missing value dilakukan dan tidak ditemukannya ada missing value pada dataset

Pengecekan outlier dilakukan dengan menghitung Z-score untuk melihat ukuran seberapa jauh sebuah nilai dari mean dataset dalam satuan standar deviasi. Lalu mengubah Z-score menjadi nilai absolut, sehingga nilai negatif juga dihitung sebagai outlier. 

## Data Preparation

Data preparation yang dilakukan adalah dengan handling outlier dan/atau missing value, pembagian variabel fitur dan target, dan pembagian train dataset dan test dataset dengan train_test_split dari library sklearn.

**Handling Missing Value**
Setelah pengecekan yang telah dilakukan pada data understanding. Pada dataset ini, tidak ditemukan missing value.

**Handling Outlier**
Penulis menghitung z-score dan menghapus data outlier berdasarkan  nilai tersebut.

1. Menerima dua parameter: `df` (DataFrame) yang akan dihapus outlier-nya, dan `threshold` (default: 3) yang menentukan batas Z-Score untuk mengidentifikasi outlier
2.  `stats.zscore`: untuk menghitung Z-Score untuk semua kolom dalam DataFrame. Z-Score mengukur seberapa jauh sebuah titik data berada dari rata-rata dalam satuan standar deviasi.
3. `np.abs`: untuk mengambil nilai absolut dari setiap nilai Z-Score, karena nilai Z-Score dapat positif atau negatif tergantung pada arah deviasi dari mean.
4. `df[(z_scores < threshold).all(axis=1)]` menghasilkan DataFrame baru (`df_filtered`) yang hanya berisi baris-baris di mana semua nilai Z-Scorenya kurang dari `threshold`.
5. `.all(axis=1)`: untuk memastikan bahwa semua kolom numerik memenuhi syarat Z-Score kurang dari `threshold` untuk setiap barisnya.

**Pembagian variabel fitur dan target**
Pada tahap ini, dilakukan pembagian fitur yang akan digunakan untuk prediksi (X) dari target (y) atau label yang diinginkan. fitur didapatkan dengan menghapus kolom "whether he/she donated blood in March 2007" dari dataframe df, sedangkan target diperoleh dari kolom itu sendiri.

**Pembagian train dan test dataset**

Data dibagi menjadi 2, yaitu data yang akan di latih (training data) dan data uji (testing data). `Train_test_split` menggunakan 80% data sebagai data latihan dan 20% sebagai data uji. Random_state=42 untuk memastikan bahwa pembagian data akan konsisten setiap kali kode digunakan.

## Modeling
Untuk modeling, penulis membuat dua model, yaitu Support Vector Machine (SVM) dan K-Nearest Neighbors (KNN). SVM adalah algoritme machine learning yang dapat digunakan untuk klasifikasi dan regresi. Cara kerja SVM adalah dengan mengolah data menjadi Hyperplane yang mengklasifikasikan ruang input menjadi dua kelas. Sedangkan KNN merupakan algoritma yang digunakan untuk mengidentifikasi adanya persamaan antara data baru dan lama. Dengan memasukkan data baru tersebut dalam kategori yang paling serupa dengan kategori yang sudah ada sebelumnya.

**Modeling dengan SVM**
Penulis membuat model SVM dengan `SVC()`. Lalu dengan `param_dist_svm` yang berisi daftar hyperparameter yang akan dieksplorasi dalam pencarian acak `RandomizedSearchCV`. Penulis menggunakan `make_pipeline` untuk membuat pipeline yang memadukan normalisasi data (`StandardScaler()`) dengan model `random_search_svm`. Lalu model SVM terbaik dari hasil pencarian disimpan ke dalam `svm_best_model`. 

Hyperparameter yang ditentukan pada `param_dist_svm` adalah `'C'`, `'kernel'`, dan `'gamma'`. Berikut penjelasan masing-masing parameter:
-   `'C'`: Parameter regularisasi SVM.
-   `'kernel'`: Jenis kernel SVM yang akan digunakan ('linear', 'rbf', atau 'poly').
-   `'gamma'`: Parameter kernel untuk 'rbf' dan 'poly'.

Penulis menggunakan`RandomizedSearchCV` untuk mencari kombinasi hyperparameter terbaik dengan cara yang lebih efisien daripada `GridSearchCV`, karena hanya menguji sejumlah `n_iter` kombinasi secara acak. Berikut penjelasan parameter masing-masing:
-   `n_iter=10`: Menentukan jumlah iterasi pencarian acak.
-   `cv=5`: Menentukan skema validasi silang (cross-validation) dengan 5-fold cross-validation.
-   `random_state=42`: Menentukan nilai seed untuk membuat hasil reproducible.
-   `n_jobs=-1`: Memanfaatkan semua core CPU untuk melakukan pencarian secara paralel, mempercepat proses.

Penulis menggunakan  `make_pipeline` untuk membuat pipeline yang memadukan normalisasi data (`StandardScaler()`) dengan model (`random_search_svm`). Berikut penjelasannya:
-   `pipeline.fit(X_train, y_train)`: Melatih pipeline pada data train (`X_train`, `y_train`). 
- `StandardScaler()` digunakan untuk mengubah data sehingga memiliki rata-rata nol dan varians satu sebelum diberikan ke model SVM.

Penulis menggunakan `pipeline.named_steps['randomizedsearchcv'].best_estimator_`untuk mengakses model terbaik yang ditemukan oleh `RandomizedSearchCV` melalui atribut `best_estimator_`. Model ini merupakan SVM dengan kombinasi hyperparameter terbaik berdasarkan hasil pencarian acak.

**Modeling dengan KNN**
Penulis membuat model KNN dengan `KNeighborsClassifier()`. Lalu dengan `param_dist_svm` yang berisi daftar hyperparameter yang akan dieksplorasi dalam pencarian acak `RandomizedSearchCV`. Penulis menggunakan `make_pipeline` untuk membuat pipeline yang memadukan normalisasi data (`StandardScaler()`) dengan model `random_search_svm`. Lalu model SVM terbaik dari hasil pencarian disimpan ke dalam `svm_best_model`. 	


Hyperparameter yang ditentukan pada `param_dist_svm` adalah `'n_neighbors'`) dengan nilai [3, 5, 7, 9, 11]. `'n_neighbors'` digunakan untuk menentukan jumlah tetangga terdekat yang akan dipertimbangkan oleh model saat melakukan prediksi.

Penulis menggunakan`RandomizedSearchCV` untuk mencari kombinasi hyperparameter terbaik dengan cara yang lebih efisien daripada `GridSearchCV`, karena hanya menguji sejumlah `n_iter` kombinasi secara acak. Berikut penjelasan parameter masing-masing:
-   `n_iter=5`: Menentukan jumlah iterasi pencarian acak.
-   `cv=5`: Menentukan skema validasi silang (cross-validation) dengan 5-fold cross-validation.
-   `random_state=42`: Menentukan nilai seed untuk membuat hasil reproducible.
-   `n_jobs=-1`: Memanfaatkan semua core CPU untuk melakukan pencarian secara paralel, mempercepat proses.

Penulis menggunakan  `make_pipeline` untuk membuat pipeline yang memadukan normalisasi data (`StandardScaler()`) dengan model (`random_search_svm`). Berikut penjelasannya:
- `pipeline.fit(X_train, y_train)`: melatih pipeline pada data train (`X_train`, `y_train`). 
- `StandardScaler()`: untuk mengubah data sehingga memiliki rata-rata nol dan varians satu sebelum diberikan ke model KNN.

Selanjutnya untuk Penulis menggunakan `pipeline.named_steps['randomizedsearchcv'].best_estimator_`untuk mengakses model terbaik yang ditemukan oleh `RandomizedSearchCV` melalui atribut `best_estimator_`. Model ini merupakan KNN dengan kombinasi hyperparameter terbaik berdasarkan hasil pencarian acak.

**Hyperparameter pada SVM:**
Berikut adalah penjelasan parameter yang digunakan untuk melakukan hyperparameter pada SVM:
Melakukan pencarian grid untuk model SVM dengan berbagai kombinasi hyperparameter (`C`, `kernel`, `gamma`, `max_iter`). Berikut adalah penjelasan tiap parameter:
	- `C`: untuk mengontrol trade-off antara margin yang besar dan kesalahan klasifikasi. Nilai yang dicoba adalah 0.1, 1, 10, dan 100.
	-   `kernel`:  untuk memetakan data ke dalam dimensi yang lebih tinggi. Nilai yang dicoba adalah 'linear', 'rbf', dan 'poly'.
	-   `gamma`: koefisien kernel untuk fungsi kernel 'rbf' dan 'poly'. Nilai yang dicoba adalah 'scale' dan 'auto'.
	-   `max_iter`: jumlah iterasi maksimum selama pelatihan (training). Nilai yang dicoba adalah 100, 200, dan 300.

Selanjutnya penulis melakukan hyperparameter tuning untuk memastikan bahwa model yang dihasilkan memiliki performa yang optimal.

**Hyperparameter pada KNN:**
Berikut adalah penjelasan parameter yang digunakan untuk melakukan hyperparameter pada KNN:

1. Melakukan pencarian grid untuk model KNN dengan hyperparameter `n_neighbors`. Berikut adalah penjelasannya:
	-   `'n_neighbors'`: Jumlah tetangga terdekat yang akan dipertimbangkan oleh model KNN untuk melakukan prediksi. Jumlah yang dicoba adalah [3, 5, 7, 9, 11].

Selanjutnya penulis melakukan hyperparameter tuning untuk memastikan bahwa model yang dihasilkan memiliki performa yang optimal.


## Evaluation

Evaluasi dilakukan dengan menghitung Accuracy, Precision, Recall, dan F1-score. Berikut adalah penjelasan mengenai metrik yang dipakai
- Accuracy: Persentase prediksi yang benar dari semua prediksi yang dibuat. Seberapa sering model membuat prediksi yang benar dapat diukur dengan metrik ini.
- Precision: Persentase prediksi positif yang benar dibandingkan dengan total prediksi positif yang dibuat oleh model. Ketika biaya dari false positive tinggi, metrik ini sangat penting.
- Recall: Proporsi dari instance positif yang berhasil diprediksi oleh model. Metrik ini penting ketika biaya dari false negative tinggi.
- F1-score: Skor rata-rata harmonik dari precision dan recall, yang mengimbangi keduanya. Ketika ada ketidakseimbangan antara jumlah kasus positif dan negatif, metrik ini bermanfaat.

Sebelum menghitung metrik tersebut, perlu menghitung prediksi terbaik pada masing-masing model. Setelah itu, perhitungan masing-masing metrik pada tiap model dapat dimulai. Hasil perhitungan akan dimasukkan ke dataframe `result` yang telah dibuat sebelumnya untuk memudahkan melihat hasil evaluasi.


Berikut adalah tabel evaluasi:
|  |  SVM| KNN |
|--|--|--|
|accuracy_train|  0.765009|  0.806175|
|accuracy_test|0.767123|0.760274|
|precision_train|0|0.657895|
|precision_test|0|0.473684|
|recall_train|0|0.364964|
|recall_test|0|0.264706|
|f1_score_train|0|0.469484|
|f1_score_test|0|0.339623|

Berdasarkan hasil evaluasi di atas, dapat dilihat bahwa model SVM dan KNN memiliki perbedaan performa dalam beberapa metrik evaluasi kunci seperti accuracy, precision, recall, dan F1-score. Berikut adalah analisis dari hasil evaluasi tersebut:

-   **Accuracy:** Model SVM memiliki akurasi sebesar 76.71% pada data test. Sedangkan, pada model KNN memiliki akurasi sebesar 76.03% pada data test.
-   **Precision:** Precision untuk SVM adalah 0.0 pada data traindan data test. Nilai precision yang rendah menunjukkan bahwa dari prediksi positif yang dilakukan oleh model, tidak ada yang benar. Sedangkan pada model KNN adalah 0.66 pada data train dan 0.47 pada data test. Ini menunjukkan bahwa sekitar 47% dari prediksi positif yang dilakukan oleh model KNN adalah benar.
- **Recall:** Recall untuk SVM adalah 0.0 pada data train dan data test. Ini menunjukkan bahwa model tidak mampu mengidentifikasi instance positif dengan baik. Sedangkan, recall pada model KNN adalah 0.36 pada data train dan 0.26 pada data test. Ini menunjukkan bahwa KNN dapat mengidentifikasi sekitar 26% dari instance positif dengan baik.
-   **F1-score:** F1-score untuk SVM adalah 0.0 pada data train dan data test. Nilai rendah ini menunjukkan bahwa model tidak memiliki keseimbangan yang baik antara precision dan recall. Sedangkan F1-score untuk KNN adalah 0.47 pada data train dan 0.34 pada data test. Nilai ini menunjukkan bahwa KNN memiliki keseimbangan yang lebih baik antara precision dan recall dibandingkan dengan SVM.

Hasil evaluasi di atas menunjukkan bahwa model K-Nearest Neighbors (KNN) lebih baik dibandingkan dengan model Support Vector Machine (SVM) dalam beberapa metrik evaluasi penting, seperti accuracy, recall, dan skor F1 pada data test. Baik SVM maupun KNN memiliki nilai ketepatan yang lebih rendah, yang menunjukkan bahwa mereka sulit untuk mengidentifikasi dengan akurat donor yang akan kembali menerima. Oleh karena itu, model KNN  lebih cocok untuk digunakan untuk memprediksi apakah seseorang akan kembali mendonasikan darah karena lebih baik dalam mengidentifikasi kembali donor potensial.

Tujuan utama dari proyek ini adalah untuk meningkatkan tingkat donasi dan pengelolaan sumber daya yang efisien
1. Membuat Model Prediksi yang Akurat
Dengan menggunakan model ini, dapat diprediksi perilaku donor dengan lebih baik dan membantu dalam merencanakan strategi untuk meningkatkan partisipasi dalam program donor darah. Dengan akurasi prediksi sebesar 76% pada data test dan 80% pada data train, dapat dipastikan bahwa prediksi dengan model ini akurat. Untuk meningkatkannya dapat dilakukan training lebih pada data.
2. Mengidentifikasi Pola Donasi
Pola donasi cenderung berkorelasi dengan faktor seperti frekuensi donasi sebelumnya, waktu antara donasi, dan karakteristik demografis donor. Dengan memahami pola ini, dapat dirancang kampanye yang lebih efektif dan menargetkan donor yang berpotensi untuk mendonasikan darah lagi. Analisis ini memungkinkan kami untuk membuat keputusan yang lebih ter-informasi dalam manajemen sumber daya dan strategi pemasaran.

**Strategi Implementasi**
1. Menggunakan Model Prediksi (KNN dan SVM) 
Model prediksi seperti KNN dan SVM akan digunakan untuk menganalisis data donasi darah. Hasil prediksi akan membantu dalam menargetkan donor yang lebih potensial untuk berpartisipasi dalam panggilan donor darah.
    
2.  Evaluasi Model 
Evaluasi model dilakukan dengan menggunakan metrik seperti Accuracy, Precision, Recall, dan F1-score. Hasil evaluasi akan memberikan pemahaman yang lebih mendalam tentang kinerja model dan membantu dalam memilih model yang paling efektif.
3. Pengelolaan Sumber Daya
Dengan menggunakan hasil prediksi dari model, kita dapat mengalokasikan sumber daya dengan lebih efisien. Kampanye dan pengingat akan difokuskan pada donor dengan kemungkinan tinggi untuk mendonasikan darah kembali, mengurangi pemborosan sumber daya pada donor yang kemungkinan besar tidak akan merespons.