
# Laporan Proyek Machine Learning - Nadhira Apta Maheswari

  

## Project Overview
Dalam era digital saat ini, layanan streaming telah menjadi bagian integral dari kehidupan sehari-hari. HBO adalah dalah satu platform streaming yang menawarkan beragam film dan acara TV yang menarik. Namun, dengan banyaknya konten yang tersedia, pengguna sering kali menghadapi kesulitan dalam menemukan film atau acara TV yang sesuai dengan preferensi mereka. Oleh karena itu, adanya sistem rekomendasi menjadi sangat penting untuk meningkatkan pengalaman pengguna dengan menyediakan rekomendasi konten tontonan.

Sistem rekomendasi yang efektif dapat membantu pengguna menemukan konten yang sesuai dengan minat mereka sehingga dapat meningkatkan kepuasan pengguna dan memperpanjang waktu mereka menggunakan platform.

Dalam proyek ini akan dikembangkan dua sistem rekomendasi yang fokus pada , pertama berdasarkan nilai IMDb yang akan membantu pengguna menemukan konten dengan ulasan yang baik dan populer di kalangan pemirsa lain. Kedua adalah sistem rekomendasi berdasarkan genre yang memungkinkan pengguna untuk menemukan film dan acara TV yang sesuai dengan preferensi genre mereka. Kedua pendekatan ini akan membantu dalam meningkatkan tingkat partisipasi pengguna dan memastikan bahwa mereka selalu memiliki akses ke konten yang relevan dan menarik.

## Business Understanding


### Problem Statements
Dengan banyaknya konten yang tersedia di HBO, pengguna sering kali menghadapi kesulitan dalam menemukan film atau acara TV yang sesuai dengan preferensi mereka. Ini dapat menyebabkan pengalaman pengguna yang kurang optimal dan menurunkan keterlibatan dengan platform.

Untuk mengatasi masalah ini, harus ditemukan cara yang efektif untuk meningkatkan pengalaman pengguna. Salah satu cara yang dapat dilakukan adalah dengan membuat sistem rekomendasi konten film atau acara di platform HBO.

  

### Goals

Berikut adalah tujuan dari proyek ini:

- Memberikan rekomendasi yang lebih relevan dan dipersonalisasi sesuai dengan selera pengguna untuk meningkatkan kepuasan pengguna.
-   Mengurangi waktu yang dihabiskan pengguna untuk mencari konten yang sesuai.
  

### Solution statements
Berikut adalah solusi dilakukan oleh penulis:
- Membuat sistem yang merekomendasikan film dan acara TV berdasarkan nilai IMDb, sehingga pengguna dapat menemukan konten yang populer di kalangan pengguna lain
- Membuat sistem yang merekomendasikan film dan acara TV berdasarkan genre, sehingga pengguna dapat dengan mudah menemukan konten sesuai dengan minat genre pengguna.


## Data Understanding

Dataset HBO Content menyediakan informasi lengkap tentang acara TV dan film yang tersedia di HBO dan HBO Max. Dataset yang dipakai pada proyek ini adalah data HBO content saja, dimana ada sebanyak 1386 data dengan 53 variabel (kolom). Dataset ini mencakup berbagai aspek dari konten tersebut, seperti judul, jenis, tahun rilis, rating , skor IMDb, skor Rotten Tomatoes, dekade, kategori skor IMDb, berbagai genre, dan berbagai platform dimana konten itu dapat diakses.

Dataset yang dipakai: [HBO and HBO Max Content Dataset](https://www.kaggle.com/datasets/thedevastator/hbo-and-hbo-max-content-dataset).

**Variabel-variabel pada HBO Content dataset adalah sebagai berikut:**

- **title**: Judul acara TV atau film. (Teks)
- **type**: Jenis konten, apakah acara TV atau film. (Teks)
- **year**: Tahun rilis konten. (Numerik)
- **rating**: Kelompok usia yang sesuai untuk konten berdasarkan sistem rating yang sudah ada. (Teks)
- **imdb_score**: Skor IMDb dari konten, menunjukkan popularitas dan kualitasnya di antara penonton. (Numerik)
- **rotten_score**: Skor Rotten Tomatoes dari konten, menunjukkan penerimaan kritisnya. (Numerik)
- **decade**: Dekade di mana konten tersebut termasuk. (Teks)
- **imdb_bucket**: Kategorisasi konten berdasarkan skor IMDb-nya, menunjukkan rentang popularitasnya. (Teks)
- **genres_Action_Adventure**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Action/Adventure. (Boolean)
- **genres_Animation**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Animation. (Boolean)
- **genres_Biography**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Biography. (Boolean)
- **genres_Children**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Hiburan Anak. (Boolean)
- **genres_Comedy**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Komedi. (Boolean)
- **genres_Crime**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Kejahatan. (Boolean)
- **genres_Cult**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Cult. (Boolean)
- **genres_Documentary**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Dokumenter. (Boolean)
- **genres_Drama**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Drama. (Boolean)
- **genres_Family**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Keluarga. (Boolean)
- **genres_Fantasy**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Fantasi. (Boolean)
- **genres_Food**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Makanan. (Boolean)
- **genres_Game Show**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Game Show. (Boolean)
- **genres_History**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Sejarah. (Boolean)
- **genres_Horror**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Horor. (Boolean)
- **genres_Independent**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Independen. (Boolean)
- **genres_LGBTQ**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre LGBTQ. (Boolean)
- **genres_Musical**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Musikal. (Boolean)
- **genres_Mystery**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Misteri. (Boolean)
- **genres_Reality**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Realitas. (Boolean)
- **genres_Romance**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Romansa. (Boolean)
- **genres_Science_Fiction**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Fiksi Ilmiah. (Boolean)
- **genres_Sport**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Olahraga. (Boolean)
- **genres_Stand_up_Talk**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Stand-up/Talk. (Boolean)


- **genres_Thriller**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Thriller. (Boolean)
- **genres_Travel**: Nilai biner yang menunjukkan apakah konten termasuk dalam genre Perjalanan. (Boolean)
- **platforms_acorntv**: Nilai biner yang menunjukkan apakah konten tersedia di platform Acorn TV. (Boolean)
- **platforms_amazon_prime**: Nilai biner yang menunjukkan apakah konten tersedia di platform Amazon Prime. (Boolean)
- **platforms_cinemax**: Nilai biner yang menunjukkan apakah konten tersedia di platform Cinemax. (Boolean)
- **platforms_epix**: Nilai biner yang menunjukkan apakah konten tersedia di platform Epix. (Boolean)
- **platforms_fandor**: Nilai biner yang menunjukkan apakah konten tersedia di platform Fandor. (Boolean)
- **platforms_free**: Nilai biner yang menunjukkan apakah konten tersedia secara gratis. (Boolean)

Untuk memahami data, penulis melihat tipe data dengan melihat tabel informasi serta dengan melihat informasi mengenai total, rata-rata, angka minimal, dan angka maximal

**Pengecekan missing value dan outlier**
Pengecekan missing value dilakukan pada seluruh data. Ditemukan pada kolom type sebanyak 1157, rating sebanyak 297,  imdb_score sebanyak 60, rotten_score sebanyak 588, imdb_bucket sebanyak 60.

Pengecekan outlier dilakukan dengan menghitung Z-score untuk melihat ukuran seberapa jauh sebuah nilai dari mean dataset dalam satuan standar deviasi serta memvisualisasikannya dengan boxplot. Dimana **tidak** ditemukannya ada outlier pada dataset ini.

## Data Preparation
Data preparation yang dilakukan adalah dengan handling missing value dan/atau outlier, mengambil genre sebagai fitur untuk content based filtering, menentukan format dan skala untuk untuk collaborative filtering, dan membagi data menjadi train dan test set.

**Handling missing value**
Ditemukan pada kolom type sebanyak 1157, rating sebanyak 297,  imdb_score sebanyak 60, rotten_score sebanyak 588, imdb_bucket sebanyak 60. Berikut bagaimana penulis melakukan handling missing value:
 1. Pada kolom 'type' dan 'rating' dengan menggunakan mode (nilai yang paling sering muncul) dari masing-masing kolom. Mode dipilih karena biasanya jenis dan rating memiliki kategori yang sering
 2. Pada kolom 'imdb_score' dan 'rotten_score' dengan rata-rata (mean) dari masing-masing kolom. Rata-rata dipilih karena skor ini bersifat numerik dan rata-rata memberikan estimasi yang baik untuk nilai yang hilang
 3. Pada kolom 'imdb_bucket' dengan mode dari kolom tersebut. 'imdb_bucket' merupakan kategori yang mengelompokkan skor IMDb ke dalam berbagai bucket, sehingga pengisian dengan mode mempertahankan distribusi kategori tersebut.

**Mengambil genre sebagai fitur untuk content based filtering**
Berikut cara untuk mempersiapkan melakukan content based filtering:
 1. Mengambil nama-nama kolom dari indeks 9 hingga 34 (kolom yang berisi
    genre-genre) dan mengonversinya menjadi daftar (list) `genres_list`.
2. Dengan menggunakan fungsi `apply` pada DataFrame `df`, setiap baris dari kolom-kolom genre yang ada di `genres_list` digabungkan
    menjadi satu string teks. Penggabungan dilakukan dengan mengambil
    indeks (nama kolom) dari kolom genre yang memiliki nilai True (1),
    dan hasilnya digabungkan menggunakan spasi (' ').

**Menentukan format untuk untuk collaborative filtering**
Berikut cara untuk mempersiapkan melakukan collaborative filtering:
1. Menginisialisasi objek `Reader` dari pustaka `surprise`. `Reader` digunakan untuk membaca dataset dalam format tertentu dan mengatur skala rating yang digunakan. Parameter `rating_scale=(1, 10)` menunjukkan bahwa skala rating dari dataset ini adalah dari 1 hingga 10. `Reader` digunakan untuk menentukan cara membaca dataset, termasuk skala rating
2. Dataset dari DataFrame `df` ke dalam objek `Dataset` dari `surprise`. Kolom-kolom yang dimuat dari DataFrame ini adalah 'index', 'title', dan 'imdb_score'

**Membagi data menjadi train dan test set**
Berikut adalah penjelasan pembagian ini:
-   trainset dan testset: Variabel untuk menyimpan hasil dari fungsi `train_test_split`. `trainset` akan berisi bagian data yang akan digunakan untuk melatih model, sementara `testset` berisi bagian data yang akan digunakan untuk menguji model.
- test_size: Parameter yang menentukan ukuran data uji sebagai proporsi dari keseluruhan dataset. Pada proyek ini, `test_size=0.2` menunjukkan bahwa 20% dari data akan digunakan sebagai data uji, sementara 80% lainnya akan digunakan sebagai data pelatihan.
-  random_state: Parameter ini digunakan untuk menetapkan nilai seed agar hasil split data bisa direproduksi dengan konsisten. Dalam hal ini, `random_state=42` digunakan agar hasil split data tetap sama setiap kali Anda menjalankan kode ini, selama Anda menggunakan seed yang sama.

## Modeling

**Content Based Filtering**
Menghitung similarity matrix dengan metrik Cosine Similarity berdasarkan data yang telah diubah menjadi representasi TF-IDF. Data yang dipakai untuk pada content based filtering ini adalah berdasarkan genre konten. Penulis memilih menggunakan cosine similarity karena lebih cocok untuk mengukur kesamaan berdasarkan arah atau orientasi dari vektor fitur dimana dalam genre film, penting untuk menilai seberapa serupa dua film berdasarkan jenis genre yang mereka miliki, tanpa memperhatikan jumlah atau intensitas fitur-genre tertentu
-   **TF-IDF Vectorization**: Digunakan untuk mengubah teks genre menjadi representasi numerik berdasarkan nilai TF-IDF.
-   **Cosine Similarity**: Digunakan untuk menghitung seberapa mirip dua item berdasarkan representasi TF-IDF mereka.

Berikut langkah-langkah beserta penjelasannya:
1. `fit_transform(df_1['genres_combined'])`: Method ini mengubah kolom teks 'genres_combined' dari dataframe `df` menjadi matriks TF-IDF. TF-IDF (Term Frequency-Inverse Document Frequency) adalah metode untuk mengukur pentingnya sebuah kata dalam dokumen relatif terhadap koleksi dokumen lain dalam korpus
2. `cosine_similarity(tfidf_matrix, tfidf_matrix)`: Fungsi `cosine_similarity` dari `sklearn.metrics.pairwise` digunakan untuk menghitung similarity matrix berdasarkan metrik Cosine Similarity antara semua pasangan dokumen dalam `tfidf_matrix`. Cosine Similarity mengukur kedekatan arah antara dua vektor dalam ruang berdimensi banyak dan sering digunakan dalam sistem rekomendasi untuk mengukur seberapa mirip dua item berdasarkan profil mereka
3. Lalu mengonversi matriks `cosine_sim` menjadi dataframe pandas dengan indeks dan kolom yang sama yaitu judul (`title`) dari dataframe `df`.
4. Fungsi `get_recommendations(title, similarity_df=cosine_sim_df)` bertujuan untuk memberikan rekomendasi film atau TV show berdasarkan judul yang diberikan (`title`), menggunakan metode Cosine Similarity
	-  `title`: judul film atau TV show yang akan digunakan sebagai titik awal untuk mencari rekomendasi yang serupa.
	- `similarity_df`: dataframe yang berisi nilai cosine similarity antara judul-judul film atau TV show dalam dataset. Secara default, dataframe ini disebut `cosine_sim_df`.

Berikut adalahoutput  top 10 recommendation untuk film "Game of Thrones"
Rekomendasi Cosine Similarity untuk 'Game of Thrones': 
title|cosine similarity
--|--
Match Point |1.0
Carnivàle| 1.0 
Glass |1.0 
Ma |1.0 
The Recruit| 1.0 
Pandorum |1.0 
The Mighty Ducks |1.0 
Galveston |1.0 
Teeth |1.0 
Walking and Talking| 1.0



**Collaborative Filtering**
Collaborative Filtering adalah teknik dalam sistem rekomendasi yang memanfaatkan informasi dari sejumlah pengguna (user) untuk membuat prediksi atau rekomendasi terhadap item yang mungkin diminati oleh pengguna lain. Pada proyek ini, filtering akan menggunakan data nilai IMDb.

Pertama dengan menginisialisasi objek `model` sebagai instansiasi dari kelas `SVD`, yang siap untuk digunakan dalam proses pelatihan dan prediksi. SVD (Singular Value Decomposition) adalah salah satu metode dalam Collaborative Filtering yang umum digunakan untuk sistem rekomendasi.
Selanjutnya dilakukan training data yang telah di split sebelumnya. Lalu dengan menggunakan `model.test(testset)` untuk memprediksi nilai peringkat atau rating untuk setiap pasangan pengguna-item dalam test set.

Lalu berikut penjelasan untuk mendapatkan top 10 rekomendasi:
- predictions: Merupakan daftar prediksi yang dihasilkan oleh model Collaborative Filtering. Setiap prediksi biasanya berisi informasi tentang pengguna (uid), item (iid), dan nilai prediksi (est).
- n (opsional): Jumlah prediksi teratas yang ingin diambil. Secara default, nilai n adalah 10.
- Variabel top_predictions: Menyimpan hasil dari pemanggilan fungsi get_top_n() dengan predictions (daftar prediksi dari model) sebagai argumennya. Ini akan berisi daftar dari 10 prediksi teratas berdasarkan nilai prediksi (est).
- Perulangan for: Digunakan untuk iterasi melalui top_predictions (daftar prediksi teratas).
- enumerate(top_predictions): Memberikan indeks (i) dan nilai (pred) dari setiap elemen dalam top_predictions.
- print(f'{i+1}: {pred.uid} --> {pred.iid} (Prediction: {pred.est})'): Mencetak setiap prediksi dengan format yang jelas:
	- i+1: Nomor urutan prediksi (dimulai dari 1).
	- pred.uid: ID pengguna untuk prediksi tersebut.
	- pred.iid: ID item untuk prediksi tersebut.
	- pred.est: Nilai prediksi (est) yang menunjukkan perkiraan rating atau preferensi pengguna terhadap item tersebut

Berikut adalah outputnya:
No urut|ID unik pengguna|Judul|Prediksi
--|--|--|--
1|492| Atlanta's Missing and Murdered: The Lost Children | 6.848123374696545
2| 87|The Manchurian Candidate |6.858442961834548
3| 749| Empire Falls |6.836187145719143
4| 751| Empire Falls |6.836187145719143
5| 748 | Empire Falls | 6.836187145719143
6|1300|Episode #1.1 |6.8035034355273
7|1069 |Slipping Into Darkness |6.7926734676097595
8|476|Harsh Times|6.7926734676097595
9| 157| Rio |6.7926734676097595
10| 1072 |Toxic Hot Seat |6.7926734676097595


  

## Evaluation

**Content Based Filtering**
Evaluasi pada content based filtering dengan menghitung precision, recall, dan Mean Average Precision (MAP). Berikut adalah penjelasan dari parameter yang dipakai:
- `predictions`: daftar prediksi yang dihasilkan oleh model Collaborative Filtering. Setiap prediksi berisi informasi tentang pengguna (uid), nilai rating sebenarnya (true_r), nilai prediksi (est), dan informasi tambahan jika ada.
-  `k`: Jumlah prediksi teratas yang akan dievaluasi untuk Precision dan Recall. Secara default, nilainya adalah 10.
- `threshold`: Ambang batas untuk menentukan apakah suatu prediksi dianggap relevan atau tidak. Secara default, nilai threshold adalah 3.5.

Berikut adalah nilai evaluasi nya:
- Precision at K: 1.0000
Ini berarti bahwa untuk setiap pengguna, model content-based filtering berhasil merekomendasikan setidaknya satu item yang sesuai dengan preferensi pengguna dalam top-k prediksi.
Precision sebesar 1.0000 menunjukkan bahwa semua item yang direkomendasikan relevan dengan preferensi pengguna.
- Recall at K: 1.0000
Recall sebesar 1.0000 menunjukkan bahwa model berhasil menemukan semua item yang relevan dalam top-k prediksi untuk setiap pengguna.
Ini mengindikasikan bahwa tidak ada item yang relevan yang terlewat dalam proses rekomendasi.
- Mean Average Precision (MAP): 1.0000
MAP sebesar 1.0000 menunjukkan bahwa model content-based filtering memberikan precision yang sempurna pada setiap prediksi, tanpa adanya false positives.

**Collaborative Filtering**
Evaluasi pada collaborative filtering dengan menghitung RMSE, MAE, Precision, dan Recall. Berikut adalah penjelasan dari parameter yang dipakai:
- `model.test(testset)`: Memanggil metode `test` dari model, dengan `testset` sebagai parameter. Ini menghasilkan daftar prediksi untuk setiap pasangan pengguna-item dalam `testset`, berisi informasi seperti pengguna (`uid`), item (`iid`), nilai rating sebenarnya (`true_r`), nilai prediksi (`est`), dan informasi tambahan jika ada.
-  `accuracy.rmse(predictions)`: Menghitung Root Mean Square Error (RMSE) antara nilai prediksi (`est`) dan nilai sebenarnya (`true_r`) dari `predictions`.
-   `accuracy.mae(predictions)`: untuk menghitung Mean Absolute Error (MAE) antara nilai prediksi (`est`) dan nilai sebenarnya (`true_r`) dari `predictions`.
- `precision_recall_at_k(predictions, k=10, threshold=7)`:  fungsi untuk menghitung Precision dan Recall pada nilai threshold tertentu (`threshold`) dan untuk k-prediksi teratas (`k`).
	- `predictions`: Daftar prediksi dari model, sama seperti yang dihasilkan dari `model.test(testset)`.
	-   `k`: Jumlah prediksi teratas yang akan dievaluasi. Secara default adalah 10.
	-   `threshold`: Nilai threshold yang digunakan untuk menganggap suatu prediksi sebagai "relevan". Secara default adalah 7.

Lalu hasil dari evaluasi ini adalah
- RMSE: 1.0404
Root Mean Square Error (RMSE) sebesar 1.0404 mengindikasikan bahwa terdapat perbedaan antara nilai prediksi model dengan nilai sebenarnya dalam data uji. Semakin rendah nilai RMSE, semakin baik performa model.
- MAE: 0.8010
Mean Absolute Error (MAE) sebesar 0.8010 juga mengukur kesalahan rata-rata dari prediksi model terhadap nilai sebenarnya. Semakin rendah nilai MAE, semakin akurat prediksi model.
- Precision at K: 0.0000
Precision at K sebesar 0.0000 menunjukkan bahwa tidak ada satupun dari top-k prediksi yang relevan dengan preferensi pengguna. Ini bisa berarti bahwa model collaborative filtering tidak berhasil merekomendasikan item yang sesuai dengan preferensi pengguna dalam top-k prediksi yang diuji.
- Recall at K: 0.0000
Recall at K sebesar 0.0000 menunjukkan bahwa model tidak berhasil menemukan item-item yang relevan dalam top-k prediksi untuk setiap pengguna. Ini menunjukkan bahwa model tidak memberikan rekomendasi yang memadai untuk kebutuhan pengguna dalam skenario uji.

Berikut penjelasannya dari semua metrik yang dipakai:
-   `RMSE`: Root Mean Square Error dari prediksi model terhadap `testset`.
-   `MAE`: Mean Absolute Error dari prediksi model terhadap `testset`.
- `MAP`: rata-rata dari AP untuk semua pengguna dalam kumpulan data. Ini memberikan gambaran keseluruhan tentang kualitas rekomendasi sistem secara agregat
-   `Precision at K`: Rata-rata Precision dari prediksi model untuk top-k prediksi.
-   `Recall at K`: Rata-rata Recall dari prediksi model untuk top-k prediksi.

Content Based Filtering memberikan hasil evaluasi yang sangat baik dengan nilai precision, recall, dan MAP mencapai 1.0000, menunjukkan bahwa model mampu memberikan rekomendasi yang sangat relevan dan sesuai dengan preferensi pengguna. Pada Collaborative Filtering meskipun memiliki nilai RMSE dan MAE yang relatif rendah, nilai precision dan recall yang sangat rendah menunjukkan bahwa model ini mungkin mengalami kesulitan dalam menyesuaikan rekomendasi dengan preferensi individual pengguna dalam skenario pengujian.

Berdasarkan hasil evaluasi, content based filtering telah terbukti efektif dalam memberikan rekomendasi yang sangat relevan dan dipersonalisasi dengan nilai Precision, Recall, dan MAP mencapai 1.0000. Hal ini sesuai dengan tujuan proyek untuk meningkatkan kepuasan pengguna dengan memberikan rekomendasi yang sesuai dengan selera mereka. Model ini juga membantu mengurangi waktu yang dihabiskan pengguna untuk mencari konten yang sesuai, karena dapat dengan tepat mengidentifikasi dan merekomendasikan konten berdasarkan preferensi pengguna sebelumnya.
Sementara itu, evaluasi collaborative filtering menunjukkan hasil yang belum memuaskan dengan nilai Precision at K dan Recall at K yang rendah. Meskipun memiliki potensi untuk memberikan rekomendasi yang akurat berdasarkan data pengguna lain, model ini memerlukan penyesuaian lebih lanjut untuk mencapai tingkat personalisasi yang diperlukan.